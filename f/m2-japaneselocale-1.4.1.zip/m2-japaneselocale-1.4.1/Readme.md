Japanese locale for Magento
================
This is Japanese locale for Magento2.  

# Support

If you have any issues about this extension, open an issue on Github.
Technical support question is same. 

# Contribution

Any contributions are highly appreciated. Please send me a pull request.

# License

[Open Software License 3.0](http://opensource.org/licenses/osl-3.0.php)
[Academic Free License 3.0](http://opensource.org/licenses/afl-3.0.php)

# Copyright

(c) 2016 Veriteworks Inc.

***

Magento2用日本語ロケールです。
日本語でMagentoを使いたい場合はインストールしてください。


# サポートについて

不具合や改善に関するご要望は、Github上のIssueとして投稿ください。
サポートも同様です。

# パッチ・機能改善に関するコードの提供について

あらゆるパッチ・改善に関するコードのご提供を歓迎します。プルリクエストでお送りいただけると幸いです。

# ライセンス

[Open Software License 3.0](http://opensource.org/licenses/osl-3.0.php)
[Academic Free License 3.0](http://opensource.org/licenses/afl-3.0.php)

# Copyright

(c) 2016 Veriteworks Inc.